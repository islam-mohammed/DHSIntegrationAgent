using System.Windows.Controls;

namespace DHSIntegrationAgent.App.UI.Controls
{
    /// <summary>
    /// Interaction logic for LoadingOverlay.xaml
    /// </summary>
    public partial class LoadingOverlay : UserControl
    {
        public LoadingOverlay()
        {
            InitializeComponent();
        }
    }
}
