﻿using System.Windows.Controls;

namespace DHSIntegrationAgent.App.UI.Views;

public partial class EngineControlView : UserControl
{
    public EngineControlView()
    {
        InitializeComponent();
    }
}
