using System.Windows.Controls;

namespace DHSIntegrationAgent.App.UI.Views;

/// <summary>
/// Interaction logic for CreateBatchView.xaml
/// </summary>
public partial class CreateBatchView : UserControl
{
    public CreateBatchView()
    {
        InitializeComponent();
    }
}
