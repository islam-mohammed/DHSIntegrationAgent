using DHSIntegrationAgent.App.UI.Mvvm;

namespace DHSIntegrationAgent.App.UI.ViewModels;

public sealed class ContactViewModel : ViewModelBase
{
}
