﻿namespace DHSIntegrationAgent.Application.Configuration;

public sealed class AzureBlobOptions
{
    public string SasUrl { get; init; } = "";
}
