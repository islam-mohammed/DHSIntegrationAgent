namespace DHSIntegrationAgent.Domain.WorkStates;

public enum DispatchItemResult
{
    Unknown = 0,
    Success = 1,
    Fail = 2
}
