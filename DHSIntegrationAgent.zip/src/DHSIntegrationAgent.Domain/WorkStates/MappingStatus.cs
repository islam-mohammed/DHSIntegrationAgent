namespace DHSIntegrationAgent.Domain.WorkStates;

public enum MappingStatus
{
    Missing = 0,
    Posted = 1,
    Approved = 2,
    PostFailed = 3
}
