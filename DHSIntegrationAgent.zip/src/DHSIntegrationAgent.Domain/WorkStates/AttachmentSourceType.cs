namespace DHSIntegrationAgent.Domain.WorkStates;

public enum AttachmentSourceType
{
    FilePath = 0,
    RawBytesInLocation = 1,
    Base64InAttachBit = 2
}
