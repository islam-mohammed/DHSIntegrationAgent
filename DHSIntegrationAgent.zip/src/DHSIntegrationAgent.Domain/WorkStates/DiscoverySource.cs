namespace DHSIntegrationAgent.Domain.WorkStates;

public enum DiscoverySource
{
    Api = 0,
    Scanned = 1
}
