namespace DHSIntegrationAgent.Domain.WorkStates;

public enum CompletionStatus
{
    Unknown = 0,
    Completed = 1
}
