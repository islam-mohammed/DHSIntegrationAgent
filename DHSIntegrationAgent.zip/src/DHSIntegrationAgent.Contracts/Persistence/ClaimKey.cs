namespace DHSIntegrationAgent.Contracts.Persistence;

public readonly record struct ClaimKey(string ProviderDhsCode, int ProIdClaim);
