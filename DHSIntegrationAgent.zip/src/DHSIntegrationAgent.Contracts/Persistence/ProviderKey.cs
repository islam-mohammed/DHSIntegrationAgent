namespace DHSIntegrationAgent.Contracts.Persistence;

public readonly record struct ProviderKey(string ProviderCode);
